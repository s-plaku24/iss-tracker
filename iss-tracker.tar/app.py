import streamlit as st

def main():
    st.title("My App")

if __name__ == "__main__":
    main()  # <-- this MUST be called
